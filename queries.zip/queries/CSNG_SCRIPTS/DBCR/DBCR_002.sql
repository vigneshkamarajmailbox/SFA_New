-- INSERT SCRIPT FOR MDM2INTERDB (STOCK REQUEST PROCESS)

insert into mdm2interdb
(
CmpCode, 
InterDBProcess, 
ProcessType,
ProcessEnable, 
InterDBQuery, 
Entity,
ProcessSequence, 
ProcessStatus, 
StartDate, 
EndDate, 
isIncremental, 
intervals, 
MaxChangeNo, 
isDistributorWise,
IntegrationMode, 
ProcessGroup, 
BulkProcess
)
values
(
'TTKHC', 
'Stock Request', 
'R', 
'N', 
'SELECT sh.cmpcode,
       "N"                                 AS UploadFlag,
       sh.distrcode,
       s.salesmancode                      AS DistrSalesmanCode,
       Now()                               AS ReqStockNo,
       Curdate()                           AS ReqStockDate,
       Curdate()                           AS RequestDate,
       "System"                            AS ManagerId,
       "System"                            AS ManagerName,
       "A"                                 AS ApprovalStatus,
       sh.prodcode,
       p.prodname,
       sh.prodbatchcode,
       pp.mrp,
       pp.sellprice,
       pu.uomcode,
       pu.uomconvfactor,
       ( sh.saleableqty - sh.resvsaleqty ) AS RequestQty,
       ( sh.saleableqty - sh.resvsaleqty ) AS ApprovedStockQty,
       0                                   AS ReceivedStockQty,
       0                                   AS StockLoadQty,
       pu.uomcode                          AS ReqStockUOM,
       pu.uomcode                          AS ApprovedStockUOM,
       pu.uomcode                          AS ReceivedStockUOM,
       Curdate()                           AS ApprovalDate,
       Now()                               AS StockReqNo,
       ""                                  AS ReqStockQty,
       ""                                  AS Remarks,
       ""                                  AS Signature,
       Now()                               AS ModDt
FROM   stockonhand sh
       INNER JOIN distributor d
              ON sh.CmpCode = d.CmpCode
              AND sh.DistrCode = d.DistrCode
        INNER JOIN supplychainmaster sch
			ON sch.cmpCode = d.cmpCode
		   AND sch.memberCode = d.distrCode      
       INNER JOIN product p
               ON sh.cmpcode = p.cmpcode
                  AND sh.prodcode = p.prodcode
       INNER JOIN productpricing pp
                ON pp.cmpCode = sh.cmpCode
                               AND pp.prodCode = sh.prodCode
                               AND pp.prodBatchCode = sh.prodBatchCode
                               AND pp.CmpCode = sch.CmpCode
                               AND pp.fromlevel = sch.levelCode
                               AND d.GeoHierPath LIKE CONCAT("%/", pp.geoCode, "/%")
       INNER JOIN productuom pu
               ON sh.cmpcode = pu.cmpcode
                  AND sh.prodcode = pu.prodcode
       INNER JOIN salesman s
               ON sh.cmpcode = s.cmpcode
                  AND sh.distrcode = s.distrcode
                  AND sh.distrbrcode = s.distrbrcode
                  AND s.IsCreateGodown = "Y"
                  AND sh.GodownCode = s.SalesmanCode
	 WHERE (sh.SaleableQty+sh.OfferQty) -(sh.ResvSaleQty + sh.ResvOfferQty) > 0;', 
'com.botree.interdbentity.model.StockRequestEntity', 
1, 
'Success', 
'2023-08-30 13:25:01', 
'2023-08-30 13:25:01', 
'N', 
'24HRS', 
5512724, 
'Y', 
'API', 
1, 
'N'
);
