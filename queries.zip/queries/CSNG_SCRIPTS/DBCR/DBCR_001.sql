-- Create Table Script TempInvoiceHeader

CREATE TABLE tempinvoiceheader (
  CmpCode varchar(10) NOT NULL,
  DistrCode varchar(50) NOT NULL,
  OrderNo varchar(100) NOT NULL,
  OrderDt date NOT NULL,
  DistrSalesmanCode varchar(50) NOT NULL,
  UserType varchar(50) DEFAULT NULL,
  SSMType varchar(50) DEFAULT NULL,
  BalanceOs decimal(22,6) DEFAULT '0.000000',
  RouteCode varchar(100) NOT NULL,
  CustomerCode varchar(100) NOT NULL,
  Remarks varchar(150) DEFAULT NULL,
  Latitude varchar(20) DEFAULT NULL,
  Longitude varchar(20) DEFAULT NULL,
  StartTime datetime DEFAULT NULL,
  EndTime datetime DEFAULT NULL,
  TotalDiscount decimal(22,6) DEFAULT '0.000000',
  TotalTax decimal(22,6) DEFAULT '0.000000',
  TotalOrderValue decimal(22,6) DEFAULT '0.000000',
  ModDt datetime NOT NULL,
  PRIMARY KEY (CmpCode,DistrCode,OrderNo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Create Table Script TempInvocieDetails
CREATE TABLE tempssfainvoicedetails (
  CmpCode varchar(10) NOT NULL,
  DistrCode varchar(50) NOT NULL,
  OrderNo varchar(100) NOT NULL,
  ProdCode varchar(50) NOT NULL,
  ProdName varchar(100) DEFAULT NULL,
  ProdBatchCode varchar(100) NOT NULL,
  OrderQty int(11) DEFAULT '0',
  UomCode varchar(13) NOT NULL,
  SellRate decimal(22,6) DEFAULT '0.000000',
  OrderValue decimal(22,6) NOT NULL,
  SchAmt decimal(22,6) NOT NULL,
  TaxAmt decimal(22,6) NOT NULL,
  TaxCode varchar(100) DEFAULT NULL,
  CgstPerc decimal(22,6) NOT NULL,
  CgstAmt decimal(22,6) NOT NULL,
  SgstPerc decimal(22,6) NOT NULL,
  SgstAmt decimal(22,6) NOT NULL,
  UgstPerc decimal(22,6) NOT NULL,
  UgstAmt decimal(22,6) NOT NULL,
  IgstPerc decimal(22,6) NOT NULL,
  IgstAmt decimal(22,6) NOT NULL,
  FreeQty int(11) DEFAULT NULL,
  FreeInputStr varchar(50) DEFAULT NULL,
  ModDt datetime NOT NULL,
  PRIMARY KEY (CmpCode,DistrCode,OrderNo,ProdCode,ProdBatchCode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
 
 -- Create Table script tempinvoiceschemedetails
CREATE TABLE tempinvoiceschemedetails (
  CmpCode varchar(10) NOT NULL,
  DistrCode varchar(50) NOT NULL,
  OrderNo varchar(100) NOT NULL,
  SchemeCode varchar(50) NOT NULL,
  SlabNo varchar(10) NOT NULL,
  FreeProdCode varchar(50) NOT NULL DEFAULT '',
  FreeQty int(11) DEFAULT '0',
  ModDt datetime NOT NULL,
  PRIMARY KEY (CmpCode,DistrCode,OrderNo,SchemeCode,SlabNo,FreeProdCode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Create Table script tempinvoiceschemeproductrule
CREATE TABLE tempinvoiceschemeproductrule (
  CmpCode varchar(10) NOT NULL,
  DistrCode varchar(50) NOT NULL,
  OrderNo varchar(100) NOT NULL,
  SchemeCode varchar(50) NOT NULL,
  SlabNo varchar(10) NOT NULL,
  ProdCode varchar(50) NOT NULL DEFAULT '',
  DiscPerc decimal(22,6) DEFAULT '0.000000',
  DiscAmt decimal(22,6) DEFAULT '0.000000',
  ModDt datetime NOT NULL,
  PRIMARY KEY (CmpCode,DistrCode,OrderNo,SchemeCode,SlabNo,ProdCode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- Alter script tempreciptinvoice
ALTER TABLE tempreceiptinvoice
DROP COLUMN distrBrCode,
ADD COLUMN CmpCode VARCHAR(10) NOT NULL AFTER DistBrCode,
ADD COLUMN RouteCode VARCHAR(50) AFTER RetailerCode,
ADD COLUMN CollectionType char(1) DEFAULT 'M' AFTER RouteCode,
ADD COLUMN UserType VARCHAR(50) AFTER SalesmanCode,
ADD COLUMN SsmType VARCHAR(50) AFTER UserType,
ADD COLUMN InvoiceNumber VARCHAR(100) AFTER SsmType;


-- Alter script tempsalesreturn
ALTER TABLE tempsalesreturn
ADD COLUMN UserType VARCHAR(50) AFTER SalesmanCode,	
ADD COLUMN SsmType VARCHAR(50) AFTER UserType;

-- Create Table script tempsalesreturntax
CREATE TABLE tempsalesreturntax (
    CmpCode varchar(10) NOT NULL,
    DistrCode varchar(50) NOT NULL,
    SalesReturnNo varchar(50) NOT NULL,
    ProdCode varchar(50) NOT NULL,
    ProdBatchCode varchar(100) NOT NULL,
    MRP decimal(22,6) DEFAULT NULL,
    SellRate decimal(22,6) DEFAULT NULL,
    TotGrossAmt decimal(22,6) DEFAULT '0.000000',
    TotTaxableGrossAmt decimal(22,6) DEFAULT '0.000000',
    TaxPerc1 decimal(9,6) DEFAULT '0.000000',
    TaxPerc2 decimal(9,6) DEFAULT '0.000000',
    TaxAmt1 decimal(22,6) DEFAULT '0.000000',
    TaxAmt2 decimal(22,6) DEFAULT '0.000000',
    TotTaxAmt decimal(22,6) DEFAULT '0.000000',
    TotNetAmt decimal(22,6) DEFAULT '0.000000',
    TaxCode varchar(8) DEFAULT NULL,
    PRIMARY KEY (CmpCode,DistrCode,SalesReturnNo,ProdCode,ProdBatchCode)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

