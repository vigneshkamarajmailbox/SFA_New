DROP PROCEDURE IF EXISTS proc_vansales_invoice;
DELIMITER $$
CREATE PROCEDURE proc_vansales_invoice()
VANSALES_INVOICE_BLOCK:
BEGIN
    DECLARE offlineordernumber VARCHAR(50) DEFAULT NULL;
    DECLARE ordernumber   VARCHAR(100) DEFAULT NULL;
     DECLARE done tinyint DEFAULT FALSE;
    DECLARE orderno
    CURSOR FOR
    SELECT th.orderno
    FROM tempinvoiceheader th
    LEFT JOIN invoiceheader ih
		ON ih.cmpcode = th.cmpcode
		AND ih.distrcode = th.distrcode
		AND ih.invoicenumber = th.orderno
		WHERE th.ssmtype = 'van'
        AND ih.invoicenumber IS NULL;
       
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	DECLARE EXIT handler FOR SQLEXCEPTION
		BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p2 = MESSAGE_TEXT;
            SELECT 'ERROR' AS status, @p2 AS message;
            ROLLBACK;
        END;
START transaction;

OPEN orderno;
orders: LOOP
    FETCH orderno INTO  ordernumber;
    iF done THEN 
       	LEAVE orders;
	ELSE
    
    -- Insert script for invoiceheader
    INSERT INTO invoiceheader
                (
                            cmpcode,
                            distrcode,
                            distrbrcode,
                            invoicenumber,
                            godowncode,
                            invoicepattern,
                            customercode,
                            customershipcode,
                            routecode,
                            routetype,
                            salesmancode,
                            dcnumber,
                            invoicedt,
                            shipdt,
                            invoicetype,
                            invoicemode,
                            manualbillno,
                            docrefno,
                            remarks,
                            invlvldiscperc,
                            InvLvlDiscAmt,
                            totcashdiscamt,
                            totdbdiscamt,
                            totspldiscamt,
                            totschdiscamtll,
                            totschdiscamtil,
                            totcrnoteamt,
                            totdbnoteamt,
                            totgrossamt,
                            totadditions,
                            totdeductions,
                            tottaxamt,
                            totnetamt,
                            balanceos,
                            roundoffsts,
                            roundoffamt,
                            orderno,
                            deliverydt,
                            invoicestatus,
                            claimcode,
                            source,
                            modusercode,
                            moddt,
                            doctorcode,
                            totreplacementamt,
                            tottaxablegrossamt,
                            cashdiscperc,
                            otherchargesconfig,
                            octroiconfig,
                            freightconfig,
                            octroi,
                            freight,
                            othercharges,
                            allowedit,
                            doctype,
                            grnrefno,
                            invoicedisccalcby,
                            totcashdisccalcby,
                            marketretgrossamt,
                            totadjnetamt,
                            credit,
                            taxon,
                            tottaxamt1,
                            tottaxamt2,
                            tottaxamt3,
                            tottaxamt4,
                            tottaxamt5,
                            totcstamt1,
                            totcstamt2,
                            totcstamt3,
                            totcstamt4,
                            totcstamt5,
                            invoicetaxexpdate,
                            totaltcstaxamount,
                            serialnoattached
                )
    SELECT     ih.cmpcode,
               ih.distrcode,
               ih.distrcode,
			   ordernumber,
               ih.distrsalesmancode,
               'I',
               ih.customercode,
               cs.customershipcode,
               ih.routecode,
               r.routetype,
               ih.distrsalesmancode,
               ordernumber,
               ih.orderdt AS invoicedt,
               ih.orderdt AS shipdt,
               'O',
               'CR',
               NULL,
               NULL,
               ih.remarks,
               '0.000000',
               '0.000000',
               ih.totaldiscount,
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               ih.totalordervalue,
               ih.totaltax,
               '0.000000',
               ih.totaltax,
               ih.balanceos,
               ih.balanceos,
               'Y',
               '0.000000',
               ih.orderno,
               ih.orderdt,
               'D',
               NULL,
               'I',
               ih.distrcode,
               Now(),
               NULL,
               '0.000000',
               '0.000000',
               '0.000000',
               'A',
               'A',
               'A',
               '0.000000',
               '0.000000',
               '0.000000',
               0,
               'R',
               NULL,
               'P',
               'P',
               NULL,
               '0.000000',
               'Y',
               'GST',
               ih.totaltax,
               '0.000000',
               '0.000000',
               '0.000000',
               ih.totaltax,
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               NULL,
               NULL,
               '0.000000',
               'N'
    FROM tempinvoiceheader ih
    INNER JOIN customershipaddress cs
		ON ih.cmpcode = cs.cmpcode
		AND ih.customercode = cs.customercode
    INNER JOIN route r
		ON ih.cmpcode = r.cmpcode
		AND ih.distrcode = r.distrcode
		AND ih.routecode = r.routecode
    WHERE ih.orderno = ordernumber;
    
    -- Insert script for invoicedetails
    INSERT INTO invoicedetails
                (
                            distrcode,
                            distrbrcode,
                            invoicenumber,
                            cmpcode,
                            prodcode,
                            prodbatchcode,
                            TotalOrdQty,
                            invoiceqty,
                            freeqty,
                            taxcode,
                            taxperc1,
                            taxamt1,
                            taxableamt1,
                            taxperc2,
                            tax2type,
                            taxamt2,
                            taxableamt2,
                            cstcode,
                            cstperc,
                            cstamt,
                            cashdiscperc,
                            cashdiscamt,
                            dbdiscperc,
                            dbdiscamt,
                            spldiscperc,
                            spldiscamt,
                            schdiscperc,
                            schdiscamtll,
                            inputstr,
                            mrp,
                            sellrate,
                            grossamt,
                            netamt,
                            splrate,
                            splratediff,
                            actualsellrate,
                            modusercode,
                            moddt,
                            tradediscountamount,
                            taxperc3,
                            taxamt3,
                            taxperc4,
                            taxamt4,
                            taxperc5,
                            taxamt5,
                            cstper2,
                            cstamt2,
                            cstper3,
                            cstamt3,
                            cstper4,
                            cstamt4,
                            cstper5,
                            cstamt5,
                            uom1,
                            uom2,
                            orderqtyuom1,
                            orderqtyuom2,
                            replaceqty,
                            taxablegrossamt,
                            manualfreeqty,
                            unloadinvqty,
                            unloadfreeqty,
                            producttaggedfor,
                            tradeschdiscamt,
                            splschdiscamt,
                            modifiedgrossamt,
                            unreplaceqty,
                            batchexpirydate,
                            tcstaxpercent,
                            tcstaxamount
                )
    SELECT     td.distrcode,
               td.distrcode,
               ordernumber,
               td.cmpcode,
               td.prodcode,
               td.prodbatchcode,
               td.orderqty,
               td.orderqty,
               td.freeqty,
               td.taxcode,
               td.cgstperc,
               td.taxamt,
               td.cgstamt,
               NULL,
               NULL,
               NULL,
               '0.000000',
               NULL,
               NULL,
               NULL,
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               '0.000000',
               Concat(td.orderqty,td.uomcode),
               pb.mrp,
               td.sellrate,
               td.orderqty * td.sellrate,
               (td.orderqty * td.sellrate) + td.taxamt,
               NULL,
               NULL,
               td.sellrate,
               NULL,
               Now(),
               '0.000000',
               NULL,
               NULL,
               '0.000000',
               NULL,
               td.cgstperc,
               td.taxamt,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               td.uomcode,
               NULL,
               td.orderqty,
               0,
               0,
               td.orderqty * td.sellrate,
               0,
               0,
               0,
               NULL,
               '0.000000',
               '0.000000',
               NULL,
               0,
               pb.expirydt,
               '0.000000',
               '0.000000'
    FROM tempssfainvoicedetails td
    INNER JOIN product p
		ON p.cmpcode = td.cmpcode
		AND p.prodcode = td.prodcode
    INNER JOIN productbatch pb
		ON td.cmpcode = pb.cmpcode
		AND td.prodcode = pb.prodcode
		AND td.prodbatchcode = pb.prodbatchcode
    WHERE td.orderno = ordernumber;
    
    -- Insert script for invoiceschemedetails
    INSERT INTO invoiceschemedetails
                (
                            distrcode,
                            distrbrcode,
                            invoicenumber,
                            schemecode,
                            cmpcode,
                            payoutno,
                            payouttype,
                            slabno,
                            freeprodcode,
                            freeprodbatchcode,
                            freeqtyamt,
                            discperc,
                            payout,
                            claimableperc,
                            claimamt,
                            taxcode,
                            tottaxamt,
                            modusercode,
                            moddt
                )
    SELECT     sd.distrcode,
               sd.distrcode,
               ordernumber,
               sd.schemecode,
               sd.cmpcode,
               '0.000000',
               ss.payouttype,
               sd.slabno,
               sd.freeprodcode,
               IF(sd.freeprodcode IS NOT NULL, td.prodbatchcode, ''),
               IF(sd.freeprodcode IS NOT NULL, td.orderqty, ''),
               '0',
               sb.payout,
               '0.000000',
               sb.payout,
               td.taxcode,
               td.taxamt,
               sd.distrcode,
               Now()
    FROM tempinvoiceschemedetails sd
    INNER JOIN tempssfainvoicedetails td
		ON sd.cmpcode = td.cmpcode
		AND sd.distrcode = td.distrcode
		AND sd.orderno = td.orderno
	INNER JOIN schemedefinition ss
		ON ss.cmpcode = sd.cmpcode
        AND ss.schemecode = sd.schemecode
	INNER JOIN schemeslab sb
		ON sd.cmpcode = sb.cmpcode
        AND sd.schemecode = sb.schemecode
        AND sd.slabno = sb.slabno
    WHERE sd.orderno = ordernumber;
    
    -- Insert script for invoiceschemeproductrule
    INSERT INTO invoiceschemeproductrule
                (
                            distrcode,
                            distrbrcode,
                            invoicenumber,
                            schemecode,
                            cmpcode,
                            payoutno,
                            prodcode,
                            prodbatchcode,
                            invqty,
                            grossamt,
                            payout,
                            modusercode,
                            moddt
                )
    SELECT     sr.distrcode,
               sr.distrcode,
               ordernumber,
               sr.schemecode,
               sr.cmpcode,
               '1',
               sr.prodcode,
               id.prodbatchcode,
               id.orderqty,
               id.orderqty * id.sellrate,
               sb.payout,
               sr.distrcode,
               Now()
    FROM tempinvoiceschemeproductrule sr
    INNER JOIN tempssfainvoicedetails id
		ON sr.cmpcode = id.cmpcode
		AND sr.distrcode = id.distrcode
		AND sr.orderno = id.orderno
		AND sr.prodcode = id.prodcode
	INNER JOIN schemeslab sb
		ON sr.cmpcode = sb.cmpcode
        AND sr.schemecode = sb.schemecode
        AND sr.slabno = sb.slabno
    WHERE sr.orderno = ordernumber;
 
 -- Insert script for ChangeLog
    INSERT INTO changelog (CmpCode,
                           DistrCode,
                           DistrBrCode,
                           ObjectType,
                           EventType,
                           Key1,
                           Key2,
                           Key3,
                           Key4,
                           ModUserCode,
                           ModDt)
	SELECT ih.cmpCode,
		   ih.distrCode,
           ih.distrCode,
           'com.botree.csng.domain.InvoiceHeader',
           'C',
           ih.cmpCode,
           ih.distrCode,
           ih.distrCode
           ordernumber,
           ih.distrCode,
           NOW()
    FROM tempinvoiceheader ih
	WHERE ih.orderno = ordernumber;
    
    SELECT Concat(kg.prefix,Coalesce(kg.distrbrskey, ''), kg.suffix_yy, LPAD(kg.Suffix_NN + 1, 4, '0')) 
	INTO offlineordernumber
		FROM tempinvoiceheader ih
		INNER JOIN keygenerator kg
			ON kg.cmpcode = ih.cmpcode
			AND kg.distrcode = ih.distrcode
		WHERE ih.orderno = ordernumber
			AND kg.screenname = 'Order Booking';
        
    -- Insert script for offlineorderheader
    INSERT INTO offlineorderheader
                (
                            cmpcode,
                            distrcode,
                            distrbrcode,
                            orderno,
                            salesmancode,
                            customercode,
                            routecode,
                            routetype,
                            startcall,
                            endcall,
                            reasoncode,
                            coverageid,
                            orderdt,
                            status,
                            remarks,
                            source,
                            customershipcode,
                            modusercode,
                            moddt,
                            doctorcode,
                            signpath,
                            othersreason
                )
    SELECT     ih.cmpcode,
               ih.distrcode,
               ih.distrcode,
               offlineordernumber,
               ih.distrsalesmancode,
               ih.customercode,
               ih.routecode,
               r.routetype,
               ih.starttime,
               ih.endtime,
			   NULL,
               NULL,
               ih.orderdt,
               'O',
               'Order generated from SFA',
               'C',
               cs.customershipcode,
               ih.distrcode,
               Now(),
               NULL,
               NULL,
               NULL
    FROM tempinvoiceheader ih
    INNER JOIN customershipaddress cs
		ON ih.cmpcode = cs.cmpcode
		AND ih.customercode = cs.customercode
    INNER JOIN route r
		ON ih.cmpcode = r.cmpcode
		AND ih.distrcode = r.distrcode
		AND ih.routecode = r.routecode
    WHERE ih.orderno = ordernumber;
    
    -- Insert script for offlineorderdetails
    INSERT INTO offlineorderdetails
                (
                            distrcode,
                            distrbrcode,
                            orderno,
                            cmpcode,
                            prodcode,
                            prodbatchcode,
                            TotalOrderQty,
                            offerqty,
                            freeprodcode,
                            freeprodbatchcode,
                            uomcode1,
                            modusercode,
                            moddt,
                            orderqty1,
                            orderqty2,
                            uomcode2,
                            grossamt,
                            producttaggedfor,
                            originalqty,
                            inputstr,
                            prodhierlvlcode,
                            prodhiervalcode
                )
    SELECT     ih.distrcode,
               ih.distrcode,
               offlineordernumber,
               ih.cmpcode,
               id.prodcode,
               id.prodbatchcode,
               id.orderqty,
               0,
               NULL,
               NULL,
               id.uomcode,
               ih.distrcode,
               Now(),
               id.orderqty,
               0,
               NULL,
               ih.totaltax,
               NULL,
               0,
               '',
               0,
               NULL
    FROM tempinvoiceheader ih
    INNER JOIN tempssfainvoicedetails id
		ON ih.cmpcode = id.cmpcode
		AND ih.distrcode = id.distrcode
		AND ih.orderno = id.orderno
		WHERE ih.orderno = ordernumber;
 
 -- Insert script for ChangeLog
         INSERT INTO changelog (CmpCode,
                           DistrCode,
                           DistrBrCode,
                           ObjectType,
                           EventType,
                           Key1,
                           Key2,
                           Key3,
                           Key4,
                           ModUserCode,
                           ModDt)
	SELECT ih.cmpCode,
		   ih.distrCode,
           ih.distrCode,
           'com.botree.csng.domain.offlineorderheader',
           'C',
           ih.cmpCode,
           ih.distrCode,
           ih.distrCode
           offlineordernumber,
           ih.distrCode,
           NOW()
    FROM tempinvoiceheader ih
	WHERE ih.orderno = ordernumber;
    
    -- Update Key Generator
    UPDATE tempinvoiceheader ih
    INNER JOIN keygenerator kg
		ON kg.cmpcode = ih.cmpcode
		AND kg.distrcode = ih.distrcode
    SET kg.suffix_nn = kg.suffix_nn + 1
    WHERE ih.orderno = ordernumber
		AND kg.screenname = 'Order Booking';
        
        
        -- Update Stockonhand
        UPDATE tempinvoiceheader ih 
        INNER JOIN tempssfainvoicedetails id
			ON ih.cmpcode = id.cmpcode
            AND ih.distrcode = id.distrcode
            AND ih.orderno = id.orderno
		INNER JOIN stockonhand sh
			ON ih.cmpcode = sh.cmpcode
            AND ih.distrcode = sh.distrcode
            AND ih.distrsalesmancode = sh.godowncode
            AND id.prodcode = sh.prodcode
            AND id.prodbatchcode = sh.prodbatchcode
		SET sh.saleableqty = sh.saleableqty - id.orderqty
		WHERE ih.orderno = ordernumber;
        
        END IF;
END LOOP orders;
CLOSE orderno;
SELECT 'Success' AS status, 'Success' AS MESSAGE;
COMMIT;
END VANSALES_INVOICE_BLOCK $$
DELIMITER ;
