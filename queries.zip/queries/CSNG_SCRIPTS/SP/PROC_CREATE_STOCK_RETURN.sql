DROP PROCEDURE IF EXISTS PROC_CREATE_STOCK_RETURN;
DELIMITER $$
CREATE PROCEDURE PROC_CREATE_STOCK_RETURN()
BEGIN
DECLARE CmpCodeVar varchar(50) DEFAULT null;
-- EXCEPTION HANDLER
DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p2 = MESSAGE_TEXT;
            SELECT 'ERROR' AS status, @p2 AS message;
            ROLLBACK;
        END;
    START TRANSACTION;
    
    SELECT CmpCode into CmpCodeVar FROM Company;
    
    truncate table tempsalesreturntax;
    -- TO CALCULATE TAX FOR EACH PRODUCT
    CALL PROC_CALC_TAX_AMOUNT(CmpCodeVar);
    
-- UPDATE STOCK ON HAND
update stockonhand sh
inner join tempsalesreturnproduct tsrp
on sh.DistrCode = tsrp.DistrCode
and sh.GodownCode = tsrp.SalesmanCode
and sh.ProdCode = tsrp.ProductId
and sh.ProdBatchCode = tsrp.ProductBatchId
inner join tempsalesreturn tsr
on tsrp.DistrCode = tsr.DistrCode
and tsrp.SalesmanCode = tsr.SalesmanCode
and tsrp.SalesReturnNo = tsr.SalesReturnNo
left join salesreturndetails srd
on tsrp.DistrCode = srd.DistrCode
and tsrp.SalesReturnNo = srd.SalesReturnNo 
SET sh.SaleableQty = (sh.SaleableQty + tsrp.SalesReturnQty)
where tsr.SsmType = "van" and srd.SalesReturnNo is null;
    
insert into salesreturnheader
(
CmpCode, 
DistrCode, 
DistrBrCode, 
SalesReturnNo, 
CustomerCode, 
RouteCode, 
RouteType, 
SalesmanCode, 
GodownCode, 
ReturnMode,
ReturnDt, 
CustomerShipCode, 
TotGrossAmt, 
TotAdditions, 
TotDeductions, 
TotTaxAmt, 
TotNetAmt, 
ModUserCode, 
ModDt, 
TotTaxableGrossAmt, 
Source,
DocType,
SpotReplacement,
SRNStatus,
TaxOn,
TransPeriodType,
TotTaxAmt1, 
TotTaxAmt5,
FreightConfig,
PurchSalesOrderNo,
OtherChargesConfig,
OctroiConfig
)
select 
CmpCodeVar,
tsr.DistrCode,
tsr.DistBrCode,
tsr.SalesReturnNo,
tsr.RetailerCode,
tsr.RouteCode,
(select r.RouteType from route r where r.DistrCode = tsr.DistrCode and r.routecode = tsr.RouteCode),
tsr.SalesmanCode,
"MG01",
tsr.ReturnMode,
tsr.SalesReturnDate,
tsr.RetailerID,
(select SUM(TotGrossAmt) from tempsalesreturntax where DistrCode = tsr.DistBrCode and SalesReturnNo = tsr.SalesReturnNo group by CmpCode,DistrCode,SalesReturnNo),
(select SUM(TotTaxAmt) from tempsalesreturntax where DistrCode = tsr.DistrCode and SalesReturnNo = tsr.SalesReturnNo group by CmpCode,DistrCode,SalesReturnNo),
0.000000,
(select SUM(TotTaxAmt) from tempsalesreturntax where DistrCode = tsr.DistrCode and SalesReturnNo = tsr.SalesReturnNo group by CmpCode,DistrCode,SalesReturnNo),
(select SUM(TotNetAmt) from tempsalesreturntax where DistrCode = tsr.DistrCode and SalesReturnNo = tsr.SalesReturnNo group by CmpCode,DistrCode,SalesReturnNo),
tsr.DistrCode,
NOW(),
(select SUM(TotGrossAmt) from tempsalesreturntax where DistrCode = tsr.DistBrCode and SalesReturnNo = tsr.SalesReturnNo group by CmpCode,DistrCode,SalesReturnNo),
"S",
"R",
"N",
0,
"GST",
"P",
(select SUM(TaxAmt1) from tempsalesreturntax where DistrCode = tsr.DistBrCode and SalesReturnNo = tsr.SalesReturnNo group by CmpCode,DistrCode,SalesReturnNo),
(select SUM(TaxAmt2) from tempsalesreturntax where DistrCode = tsr.DistBrCode and SalesReturnNo = tsr.SalesReturnNo group by CmpCode,DistrCode,SalesReturnNo),
"A",
"",
"A",
"A"
from tempsalesreturn tsr
left join salesreturnheader srh
on tsr.SalesmanCode = srh.SalesmanCode
and tsr.SalesReturnNo = srh.SalesReturnNo 
where srh.SalesReturnNo is null 
and tsr.SsmType = "van";
    
insert into salesreturndetails
(
CmpCode,
DistrCode,
DistrBrCode,
SalesReturnNo,
InvoiceNumber,
ProdCode,
ProdBatchCode,
ReasonCode,
RtnType,
InputStr,
TotRtnQty,
UnSaleableQty,
FreeQty,
MRP,
SellRate,
GrossAmt,
TaxCode,
TaxPerc1,
TaxAmt1,
TaxableAmt1,
TaxPerc2,
TaxAmt2,
TaxableAmt2,
NetAmt,
ModUserCode,
ModDt,
TradeDiscountAmount,
TaxPerc3,
TaxAmt3,
TaxPerc4,
TaxAmt4,
TaxPerc5,
TaxAmt5,
CSTPer2,
CSTAmt2,
CSTPer3,
CSTAmt3,
CSTPer4,
CSTAmt4,
CSTPer5,
CSTAmt5,
IsReplaced,
TaxableGrossAmt,
BatchExpiryDate,
TradeSchDiscAmt,
TCSTaxPercent,
TCSTaxAmount
)
select
CmpCodeVar,
tsrp.DistrCode,
tsrp.DistBrCode,
tsrp.SalesReturnNo,
"",
tsrp.ProductId,
tsrp.ProductBatchId,
tsrp.ReasonId,
"ret",
"",
tsrp.SalesReturnQty,
0,
0,
(select MRP AS MRP from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
(select SellRate AS SellRate from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
(select TotGrossAmt AS TotGrossAmt from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
(select TaxCode AS TaxCode from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
(select TaxPerc1 AS TaxPerc1 from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
(select TaxAmt1 AS TaxAmt1 from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
(select TotTaxableGrossAmt AS TotTaxableGrossAmt from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
0.000000,
0.000000,
0.000000,
(select TotNetAmt AS TotNetAmt from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
tsrp.DistrCode,
NOW(),
0.000000,
0.000000,
0.000000,
0.000000,
0.000000,
(select TaxPerc2 AS TaxPerc2 from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
(select TaxAmt2 AS TaxAmt2 from tempsalesreturntax where DistrCode = tsrp.DistrCode and SalesReturnNo = tsrp.SalesReturnNo 
and ProdCode = tsrp.ProductId and ProdBatchCode = tsrp.ProductBatchId),
 0.000000,
 0.000000,
 0.000000,
 0.000000,
 0.000000,
 0.000000,
 0.000000,
 0.000000,
 "N",
 0.000000,
 (select pb.ExpiryDt from productbatch pb where pb.ProdCode = tsrp.ProductId and pb.ProdBatchCode = tsrp.ProductBatchId),
 0.000000,
 0.000000,
 0.000000
from 
tempsalesreturnproduct tsrp
inner join tempsalesreturn tsr
on tsrp.DistrCode = tsr.DistrCode
and tsrp.SalesmanCode = tsr.SalesmanCode
and tsrp.SalesReturnNo = tsr.SalesReturnNo
left join salesreturndetails srd
on tsrp.DistrCode = srd.DistrCode
and tsrp.SalesReturnNo = srd.SalesReturnNo 
where tsr.SsmType = "van" and srd.SalesReturnNo is null;



SELECT 'Success' AS status, 'Success' AS message;    

COMMIT;
END;
$$
DELIMITER ;

