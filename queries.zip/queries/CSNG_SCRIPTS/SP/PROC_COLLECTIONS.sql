DROP PROCEDURE IF EXISTS proc_vansales_collections;
DELIMITER $$
CREATE PROCEDURE proc_vansales_collections()
VANSALES_COLLECTIONS_BLOCK:
BEGIN
	DECLARE EXIT handler FOR SQLEXCEPTION
		BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p2 = MESSAGE_TEXT;
            SELECT 'ERROR' AS status, @p2 AS message;
            ROLLBACK;
        END;
START transaction;

-- Insert script CollectionHeader
	INSERT INTO collectionheader
		(CmpCode,
	 	DistrCode,
     		DistrBrCode,
     		CollectionRefNo,
     		CollectionDt,
     		TotalCashDiscAmt,
     		CollectionTotAmt,
     		IsApproved,
     		IsDeleted,
     		SalesmanCode,
     		RouteCode,
     		ModUserCode,
     		ModDt,
     		DelvBoyCode)
	SELECT tr.cmpCode,
	   	tr.distrcode,
       	tr.distbrcode,
       	tr.invoicereceiptno,
       	tr.invoicereceiptdate,
       	'0.000000',
       	tr.invoicereceiptamt,
       	'Y',
       	'N',
       	tr.salesmancode,
       	tr.routecode,
       	tr.distrcode,
       	NOW(),
       	''
	FROM tempreceiptinvoice tr
 	LEFT JOIN collectionheader ih
		ON ih.cmpcode = tr.cmpcode
		AND ih.distrcode = tr.distrcode
        	AND ih.distrbrcode = tr.distbrcode
		AND ih.collectionRefNo = tr.invoicereceiptno
	WHERE tr.ssmtype = 'van'
        	AND ih.collectionRefNo IS NULL;
     
  -- Insert into collectiondetails   
  	INSERT INTO collectiondetails
		(CmpCode,
     		DistrCode,
     		DistrBrCode,
     		CollectionRefNo,
     		CustomerCode,
     		CollectionMode,
     		InstrumentNo,
     		InstrumentDt,
     		BankName,
     		DiscountAmt,
     		InstrumentAmt,
     		DEPBankName,
     		DEPAccNo,
     		IsDeleted,
     		BankBranchName,
     		DEPBankBranchName,
     		DepositedDt,
     		AdjOnAccAmt,
     		BillAdjAmt,
     		CrDbAdjAmt,
     		isCancelled,
     		PenaltyAmt,
     		ModUserCode,
     		ModDt,
     		Reason,
     		OthersReason)
     	SELECT tr.cmpcode,
		tr.distrcode,
            	tr.distbrcode,
            	tr.invoicereceiptno,
            	tr.retailercode,
                IF(tr.invoicereceiptmode = 0 , 'CA', 'CH'),
            	tr.invoiceinsno,
            	tr.invoiceinsdate,
            	'',
            	'0.000000',
		tr.invoicereceiptamt,
		'',
		'',
		'N',
		'',
		'',
		NULL,
		'0.000000',
		tr.invoicereceiptamt,
		'0.000000',
		'N',
		'0.000000',
		tr.distrcode,
		NOW(),
		'',
		''
	FROM tempreceiptinvoice tr
	LEFT JOIN collectiondetails id
		ON id.cmpcode = tr.cmpcode
		AND id.distrcode = tr.distrcode
        	AND id.distrbrcode = tr.distbrcode
		AND id.collectionRefNo = tr.invoicereceiptno
	WHERE tr.ssmtype = 'van'
        	AND id.collectionRefNo IS NULL;
     
-- Insert script Billadjustments
	INSERT INTO billadjustments
		(CmpCode,
     		DistrCode,
     		DistrBrCode,
     		CollectionRefNo,
     		CustomerCode,
     		AdjustmentMode,
     		AdjustRefNo,
     		AdjustBalance,
     		AdjustmentDt,
     		AdjustmentAmt,
     		IsDeleted,
     		CollectionMode,
     		ModUserCode,
     		ModDt,
     		AdjustDiscAmt)
     	SELECT tr.cmpcode,
	 	tr.distrcode,
		tr.distbrcode,
		tr.invoicereceiptno,
		tr.retailercode,
     		'B',
     		tr.invoiceNumber,
     		id.balanceos - tr.invoicereceiptamt,
     		tr.invoicereceiptdate,
     		tr.invoicereceiptamt,
		'N',
		IF(tr.invoicereceiptmode = 0 , 'CA', 'CH'),
		tr.distrcode,
		NOW(),
     		'0.000000'
     	FROM tempreceiptinvoice tr
		LEFT JOIN billadjustments ih
		ON ih.cmpcode = tr.cmpcode
		AND ih.distrcode = tr.distrcode
        	AND ih.distrbrcode = tr.distbrcode
		AND ih.collectionRefNo = tr.invoicereceiptno
        INNER JOIN invoiceHeader id
		ON tr.cmpcode = id.cmpcode
        	AND tr.distrcode = id.distrcode
        	AND tr.distbrcode = id.distrbrcode
            AND tr.invoicereceiptno = id.invoicenumber
	WHERE tr.ssmtype = 'van'
        	AND ih.collectionRefNo IS NULL;
            
-- Insert Script for changelog
	INSERT INTO changelog (CmpCode,
                           DistrCode,
                           DistrBrCode,
                           ObjectType,
                           EventType,
                           Key1,
                           Key2,
                           Key3,
                           Key4,
                           ModUserCode,
                           ModDt)
	SELECT tr.cmpCode,
		   tr.distrCode,
           tr.distrCode,
           'com.botree.csng.domain.collectionheader',
           'C',
           tr.cmpCode,
           tr.invoicereceiptno,
           tr.distrCode,
           tr.distrCode,
           tr.distrCode,
           NOW()
    FROM tempreceiptinvoice tr
 	LEFT JOIN collectionheader ih
		ON ih.cmpcode = tr.cmpcode
		AND ih.distrcode = tr.distrcode
        	AND ih.distrbrcode = tr.distbrcode
		AND ih.collectionRefNo = tr.invoicereceiptno
	WHERE tr.ssmtype = 'van'
        	AND ih.collectionRefNo IS NULL;
            
SELECT 'Success' AS status, 'Success' AS MESSAGE;
COMMIT;
END VANSALES_COLLECTIONS_BLOCK $$
DELIMITER ;
