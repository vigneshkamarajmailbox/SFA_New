DROP PROCEDURE IF EXISTS PROC_CALC_TAX_AMOUNT;
DELIMITER $$
CREATE PROCEDURE PROC_CALC_TAX_AMOUNT(IN CmpCodeVar varchar(10))
Create_TAX_AMT_BLOCK:
BEGIN
DECLARE DistrCodeVar varchar(50) DEFAULT null;
DECLARE SalesreturnNoVar varchar(100) DEFAULT null;
DECLARE ProdCodeVar varchar(100) DEFAULT null;
DECLARE ProdBatchCodeVar varchar(100) DEFAULT null;
DECLARE ReturnQtyVar int(11) DEFAULT 0;
DECLARE ProductTaxCode varchar(10) DEFAULT NULL;

DECLARE done tinyint DEFAULT FALSE;
DECLARE productDetailsCur
        CURSOR FOR  
               select
               tsrp.DistrCode,
               tsrp.SalesReturnNo,
               tsrp.ProductId,
               tsrp.ProductBatchId,
               tsrp.SalesReturnQty
from tempsalesreturnproduct tsrp
inner join tempsalesreturn tsr
on tsrp.DistrCode = tsr.DistrCode
and tsrp.SalesmanCode = tsr.SalesmanCode
and tsrp.SalesReturnNo = tsr.SalesReturnNo
left join salesreturndetails srd
on tsrp.DistrCode = srd.DistrCode
and tsrp.SalesReturnNo = srd.SalesReturnNo 
where tsr.SsmType = "van" and srd.SalesReturnNo is null;
               
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
-- EXCEPTION HANDLER
DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p2 = MESSAGE_TEXT;
SELECT 'ERROR' AS status, @p2 AS message;
            ROLLBACK;
        END;
    START TRANSACTION;
    
SET @TaxPerc1Var =  0.000000;
SET @TaxPerc2Var =  0.000000;
SET @TaxAmt1Var =  0.000000;
SET @TaxAmt2Var =  0.000000;
SET @TotTaxAmtVar =  0.000000;
SET @TotNetAmtVar =  0.000000;
SET @SellRate = 0.000000;
SET @MRP = 0.000000;

-- SET @SellRate = 0;
-- SET @MRP = 0;

    
    OPEN productDetailsCur; 
        getProductDetails : LOOP
                    FETCH productDetailsCur 
                    into 
                    DistrCodeVar,
                    SalesreturnNoVar,
                    ProdCodeVar,
					ProdBatchCodeVar,
                    ReturnQtyVar;
                    iF done THEN 
                    LEAVE getProductDetails;
                    ELSE
					SET @CustomerCode = (select RetailerCode from tempsalesreturn where SalesReturnNo = SalesreturnNoVar);
                    SET @SalesmanCode = (select SalesmanCode from tempsalesreturn where SalesReturnNo = SalesreturnNoVar);
                    SET @SellRate = (select SellPrice from productpricing 
                                                         where CmpCode = CmpCodeVar 
                                                         and ProdCode = ProdCodeVar 
                                                         and ProdBatchCode = ProdBatchCodeVar
														 and FromLevel = (select LevelCode 
                                                                          from supplychainmaster 
                                                                          where MemberCode = DistrCodeVar));
					SET @MRP = (select MRP from productpricing 
                                                         where CmpCode = CmpCodeVar 
                                                         and ProdCode = ProdCodeVar 
                                                         and ProdBatchCode = ProdBatchCodeVar
                                                         and FromLevel = (select LevelCode 
                                                                          from supplychainmaster 
                                                                          where MemberCode = DistrCodeVar));
                                 
                     SET @GrossAmt = ReturnQtyVar * @SellRate;
                                                         
                     SET @FromState = (select GSTStateCode from GSTDistributor where DistrCode = DistrCodeVar); 
                     SET @ToState = (select GSTStateCode from customershipaddress 
                                             where customercode = @CustomerCode);
                                           
                      if @FromState = @ToState THEN
                          SET @TaxType = "G";
					  else
                           SET @TaxType = "I";
                      END if; 
                      
				

                     INSERT INTO tempsalesreturntax
                          (
							 CmpCode,
					         DistrCode,
                             SalesReturnNo,
                             ProdCode,
                             ProdBatchCode,
                             MRP,
                             SellRate,
                             TotGrossAmt,
                             TotTaxableGrossAmt,
                             TaxPerc1,
							 TaxPerc2,
                             TaxAmt1,
                             TaxAmt2,
                             TotTaxAmt,
                             TotNetAmt,
                             TaxCode
                          )
                          SELECT 
                               CmpCodeVar,
                               DistrCodeVar,
                               SalesreturnNoVar,
                               ProdCodeVar,
                               ProdBatchCodeVar,
                               @MRP,
                               @SellRate,
                               @GrossAmt,
                               @GrossAmt,
                               @TaxPerc1Var:=IF(@TaxType = "G",td.outputTaxPerc,td.outputTaxPerc),
                               @TaxPerc2Var:=IF(@TaxType = "G",td.outputTaxPerc,0.000000),
                               @TaxAmt1Var:=(@GrossAmt * (@TaxPerc1Var/100)),
                               @TaxAmt2Var:=(@GrossAmt * (@TaxPerc2Var/100)),
                               @TotTaxAmtVar:=(@TaxAmt1Var + @TaxAmt2Var),
                               @TotNetAmtVar:=@GrossAmt + @TotTaxAmtVar,
							   th.taxCode
		                          FROM 
			                           TaxStructureHeader th,
			                           TaxStructureDetails td,
			                           ProductTax ptx 
		                          WHERE 
			                           ptx.taxState = th.taxState 
		 	                      AND ptx.taxType = th.taxType 
		 	                      AND ptx.taxCode = th.taxCode 
		 	                      AND ptx.effectiveFrom = th.effectiveFrom
		 	                      AND ptx.cmpCode = th.cmpCode
		 	                      AND ptx.modDt = (SELECT MAX(pt.modDt) 
				                                          FROM ProductTax pt 
														  WHERE pt.taxState = @FromState
														  AND pt.prodCode = ProdCodeVar
				                                          AND pt.taxType = @TaxType
				                                          AND pt.cmpCode = CmpCodeVar
				                                          AND pt.effectiveFrom <= CURDATE() )  
								  AND td.taxState = th.taxState 
		 	                      AND td.taxType = th.taxType 
		 	                      AND td.taxCode = th.taxCode 
		 	                      AND td.effectiveFrom = th.effectiveFrom 
		 	                      AND td.cmpCode = th.cmpCode
		 	                      AND th.effectiveFrom <= CURDATE()
		 	                      AND th.taxType = @TaxType
		 	                      AND th.taxState = @FromState
		 	                      AND ptx.prodCode = ProdCodeVar
								  AND ptx.cmpCode = CmpCodeVar limit 1;
                    END IF;
    END LOOP getProductDetails;
    CLOSE productDetailsCur;
COMMIT;

SELECT 'Success' AS status, 'Success' AS message;
END Create_TAX_AMT_BLOCK$$
DELIMITER ;
